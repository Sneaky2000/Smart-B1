package com.example.cupertino_datepicker_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
